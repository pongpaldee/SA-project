<?php
if (!defined('WEB_ROOT')) {
	exit;
}
?>
<div class="panel panel-info">
  <div class="panel-heading">widget</div>
  <div class="panel-body">
		[WIDGET]
  </div>
</div>
