<?php
if (!defined('WEB_ROOT')) {
	exit;
}
?>
<p align="center"><a href="https://www.facebook.com/pongpaldee" target="_blank"><image src="C:/xampp/htdocs/plaincart/images/LOgo.jpg" class="img-rounded img-responsive"></a></p>
<hr>