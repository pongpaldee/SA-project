<?php
require_once '../library/config.php';
require_once '../library/category-functions.php';
require_once '../library/product-functions.php';
require_once '../library/cart-functions.php';

if(isset($_GET['productAddTominCart'])){
	$productId = $_GET['productAddTominCart'];
	$sql = "SELECT pd_id, pd_qty
	        FROM tbl_product
			WHERE pd_id = $productId";
	$result = dbQuery($sql);
	$numRow = dbNumRows($result);

	if (dbNumRows($result) != 1) {
		exit();
	} else {
		$row = dbFetchAssoc($result);
		$currentStock = $row['pd_qty'];

		if ($currentStock == 0) {
			setError('The product you requested is no longer in stock');
			header('Location: cart.php');
			exit;
		}
	}		
	
	$sid = session_id();
	
	$sql = "SELECT pd_id
	        FROM tbl_cart
			WHERE pd_id = $productId AND ct_session_id = '$sid'";
	$result = dbQuery($sql);
	
	if (dbNumRows($result) == 0) {
		$sql = "INSERT INTO tbl_cart (pd_id, ct_qty, ct_session_id, ct_date)
				VALUES ($productId, 1, '$sid', NOW())";
		$result = dbQuery($sql);
	} else {
		$sql = "UPDATE tbl_cart 
		        SET ct_qty = ct_qty + 1
				WHERE ct_session_id = '$sid' AND pd_id = $productId";		
				
		$result = dbQuery($sql);		
	}	
}

?>


<div class="panel panel-info">
  <div class="panel-heading">สินค้าที่ใส่ลงในตะกร้า</div>
  <div class="panel-body">
	<table cellspacing="0" cellpadding="2" id="minicart" class="table">
	<?php
	$subTotal = 0;
	$pd_name = "$ct_qty x $pd_name";		
	$subTotal += $pd_price * $ct_qty;
	?>
 	<tr>
   		<td><a href="#" id="product-<?php echo $pd_id; ?>" class="show-detail-product"><?php echo $pd_name; ?></a></td>
  		<td width="30%" align="right"><?php echo displayAmount($ct_qty * $pd_price); ?></td>
 	</tr>
  	<tr>
  		<span class="hidden-cat-product" id="productmini-<?php $cat_id; ?>" hidden></span>
  		<td align="right">รวมย่อย</td>
  		<td width="30%" align="right"><?php echo displayAmount($subTotal); ?></td>
 	</tr>
	</table> 
	</div>
</div>



