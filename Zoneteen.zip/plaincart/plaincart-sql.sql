--
-- ฐานข้อมูล: `zoneteen`
--

CREATE DATABASE IF NOT EXISTS zoneteen;
USE zoneteen;

--
-- โครงสร้างตาราง `tbl_cart`
--

DROP TABLE IF EXISTS `tbl_cart`;
CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `ct_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pd_id` int(10) unsigned NOT NULL DEFAULT '0',
  `ct_qty` mediumint(8) unsigned NOT NULL DEFAULT '1',
  `ct_session_id` char(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ct_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ct_id`),
  KEY `pd_id` (`pd_id`),
  KEY `ct_session_id` (`ct_session_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=314 ;

--
-- dump ตาราง `tbl_cart`
--

INSERT INTO `tbl_cart` VALUES(115, 41, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:16');
INSERT INTO `tbl_cart` VALUES(114, 36, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:12');
INSERT INTO `tbl_cart` VALUES(208, 23, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:45:32');
INSERT INTO `tbl_cart` VALUES(207, 41, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:45:30');
INSERT INTO `tbl_cart` VALUES(206, 43, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:45:29');
INSERT INTO `tbl_cart` VALUES(205, 40, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:45:26');
INSERT INTO `tbl_cart` VALUES(116, 42, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:18');
INSERT INTO `tbl_cart` VALUES(117, 40, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:19');
INSERT INTO `tbl_cart` VALUES(118, 37, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:22');
INSERT INTO `tbl_cart` VALUES(119, 28, 1, '43dd7d5b92cc0820c9dbf39042cf41fe', '2014-04-29 20:46:26');
INSERT INTO `tbl_cart` VALUES(204, 25, 4, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:45:17');
INSERT INTO `tbl_cart` VALUES(203, 37, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:44:59');
INSERT INTO `tbl_cart` VALUES(202, 27, 1, '15ca5767ad00d2e800e146d39784dcf1', '2014-05-01 13:42:55');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_parent_id` int(11) NOT NULL DEFAULT '0',
  `cat_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cat_description` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cat_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`cat_id`),
  KEY `cat_parent_id` (`cat_parent_id`),
  KEY `cat_name` (`cat_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=27 ;

--
-- dump ตาราง `tbl_category`
--

INSERT INTO `tbl_category` VALUES(10, 0, 'Converse', 'รองเท้า Converse', 'd12.jpg');
INSERT INTO `tbl_category` VALUES(11, 0, 'Nike', 'รองเท้า Nike', '2.jpg');
INSERT INTO `tbl_category` VALUES(12, 10, 'CHUCK 70 PATCHWORK HI SPRUCE GREEN', 'Chuck 70 Size 6-11 Color: Faded Spruce/Amarillo/Rose Maroon', '');
INSERT INTO `tbl_category` VALUES(13, 10, 'ALL STAR CAMO PATCH OX GREEN', 'Chuck Taylor All Star Size: 6-11 Color: Cypress Green/Khaki/White', '');
INSERT INTO `tbl_category` VALUES(14, 11, 'Nike Air Max Viva', 'วัสดุผสมที่ส่วนบนของ Nike Air Max Viva ดีไซน์มาโดยคำนึงถึงผู้หญิงทุกคน', '');
INSERT INTO `tbl_category` VALUES(15, 11, 'Nike Air Force 1 07 LV8', 'สไตล์: CZ0339-100', '');
INSERT INTO `tbl_category` VALUES(16, 0, 'Adidas', 'รองเท้า Adidas', '3.jpg');
INSERT INTO `tbl_category` VALUES(18, 0, 'New balance', 'รองเท้า New balance', '4.jpg');
INSERT INTO `tbl_category` VALUES(19, 0, 'Onitsuka Tiger', 'รองเท้า Onitsuka Tiger', '5.jpg');
INSERT INTO `tbl_category` VALUES(20, 11, 'Nike AF 1/1', 'สไตล์: CZ5093-100', '');
INSERT INTO `tbl_category` VALUES(24, 0, 'Keds', 'รองเท้า Keds', 's3.jpg');
INSERT INTO `tbl_category` VALUES(25, 0, 'Reebok', 'รองเท้า Reebox', 'd4.jpg');
INSERT INTO `tbl_category` VALUES(26, 0, 'Vans', 'รองเท้า Vans', 'd10.jpg');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_currency`
--

DROP TABLE IF EXISTS `tbl_currency`;
CREATE TABLE IF NOT EXISTS `tbl_currency` (
  `cy_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cy_code` char(3) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `cy_symbol` varchar(8) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`cy_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- dump ตาราง `tbl_currency`
--

INSERT INTO `tbl_currency` VALUES(1, 'EUR', '&#8364;');
INSERT INTO `tbl_currency` VALUES(2, 'GBP', '&pound;');
INSERT INTO `tbl_currency` VALUES(3, 'JPY', '&yen;');
INSERT INTO `tbl_currency` VALUES(4, 'USD', '$');
INSERT INTO `tbl_currency` VALUES(5, 'THB', '฿');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_order`
--

DROP TABLE IF EXISTS `tbl_order`;
CREATE TABLE IF NOT EXISTS `tbl_order` (
  `od_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `od_date` datetime DEFAULT NULL,
  `od_last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `od_status` enum('New','Paid','Shipped','Completed','Cancelled') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'New',
  `od_memo` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_state` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_postal_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_shipping_cost` decimal(5,2) DEFAULT '0.00',
  `od_payment_first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_address1` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_address2` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_city` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_state` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `od_payment_postal_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`od_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1028 ;

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_order_item`
--

DROP TABLE IF EXISTS `tbl_order_item`;
CREATE TABLE IF NOT EXISTS `tbl_order_item` (
  `od_id` int(10) unsigned NOT NULL DEFAULT '0',
  `pd_id` int(10) unsigned NOT NULL DEFAULT '0',
  `od_qty` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`od_id`,`pd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_product`
--

DROP TABLE IF EXISTS `tbl_product`;
CREATE TABLE IF NOT EXISTS `tbl_product` (
  `pd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `pd_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `pd_description` text COLLATE utf8_unicode_ci NOT NULL,
  `pd_price` decimal(9,2) NOT NULL DEFAULT '0.00',
  `pd_qty` smallint(5) unsigned NOT NULL DEFAULT '0',
  `pd_image` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pd_thumbnail` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pd_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pd_last_update` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`pd_id`),
  KEY `cat_id` (`cat_id`),
  KEY `pd_name` (`pd_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=53 ;

--
-- dump ตาราง `tbl_product`
--

INSERT INTO `tbl_product` VALUES(22, 11, 'Nike Air Force 1 ''07 LX', 'ผลิตจากวัสดุรีไซเคิลอย่างน้อย 20% ซึ่งรวมทั้ง Nike Grind ที่พื้นรองเท้าชั้นนอกและผ้าสักหลาดรีไซเคิลที่ส่วนบน', 4200.00, 8, 'รองเท้าผู้-air-force-1-07-60-tfHxT7.jpg', 'รองเท้าผู้-air-force-1-07-60-tfHxT8.jpg', '2014-05-18 15:21:15', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(23, 14, 'Nike Air Max Verona SE', 'ส่วนบนจากวัสดุผสมโดดเด่นด้วยส่วนหุ้มข้อที่นุ่มเป็นพิเศษ เท็กซ์เจอร์สุดแสบ', 5000.00, 0, 'รองเท้าผู้-air-max-verona-se-47KtK8.jpg', 'รองเท้าผู้-air-max-verona-se-47KtK9.jpg', '2014-05-26 15:26:34', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(24, 14, 'Nike Air Max 90 SE', 'Nike Air Max 90 SE เจริญรอยตามต้นแบบด้วยพื้นรองเท้าชั้นนอกลายวาฟเฟิลอันเป็นเอกลักษณ์', 5000.00, 294, 'รองเท้าผู้-air-max-90-se-D2LZtG.jpg', 'รองเท้าผู้-air-max-90-se-D2LZtG1.jpg', '2014-05-26 15:27:15', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(25, 14, 'Nike Air Max 90', 'Nike Air Max 90 เจริญรอยตามต้นแบบด้วยพื้นรองเท้าชั้นนอกลายวาฟเฟิลอันเป็นเอกลักษณ์', 3219.00, 41, 'รองเท้าผู้-air-max-90-DxngKX.jpg', 'รองเท้าผู้-air-max-90-DxngKX1.jpg', '2014-05-26 15:28:13', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(26, 12, 'CHUCK 70 PATCHWORK HI BLACK', 'Chuck 70 Color: Black, EGRET, Mouse', 3190.00, 0, '166855C_shot2-480x480.jpg', '166855C_shot2-480x4801.jpg', '2014-05-27 05:17:06', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(27, 12, 'CHUCK 70 OX BLACK/BLACK/EGRET', 'Chuck 70 Size: 4-11 Color:BLACK/BLACK/EGRET' , 2700.00, 2, '162058C-480x480.jpg', '162058C-480x4801.jpg', '2014-05-27 05:18:02', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(28, 12, 'CHUCK 70 ARCHIVE OX BLACK ORANGE', 'CHUCK 70 ARCHIVE OX BLACK ORANGE Size: 6-11', 2700.00, 59, '167813C_shot1-480x480.jpg', '167813C_shot1-480x4801.jpg', '2014-05-27 05:19:10', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(29, 13, 'ALL STAR HEEL LOGOS HI RED', 'Chuck Taylor All Star Size: 6-10', 1990.00, 0, '167173C-480x480.jpg', '167173C-480x4801.jpg', '2014-05-27 05:21:10', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(30, 16, 'DAILY 3.0 SHOES', 'Cloud White / Cloud White / Dove Grey', 2200.00, 0, 'Daily_3.0_Shoes_White_FY8449_01_standard.jpg', 'Daily_3.0_Shoes_White_FY8449_01_standard1.jpg', '2014-05-27 05:22:05', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(31, 16, 'BRAVADA MID SHOES', 'Cloud White / Core Black / Core Black', 2200.00, 2, 'Bravada_Mid_Shoes_White_FX9063_01_standard.jpg', 'Bravada_Mid_Shoes_White_FX9063_01_standard1.jpg', '2014-05-27 05:22:53', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(32, 16, 'STAN SMITH SHOES', 'Cloud White / Cloud White / Gold Metallic', 3200.00, 1, 'Stan_Smith_Shoes_White_FX5508_01_standard.jpg', 'Stan_Smith_Shoes_White_FX5508_01_standard1.jpg', '2014-05-27 05:23:59', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(33, 18, 'NEW BALANCE Fresh Foam 1080 V10 2E รองเท้าวิ่งผู้ชาย', 'อัปเปอร์ Hypoknit ช่วยกระชับตามรูปเท้า', 3294.00, 0, '98360e54ea770f9989d047824af11d18.jpg', '98360e54ea770f9989d047824af11d181.jpg', '2014-05-27 05:29:36', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(34, 19, 'MEXICO 66', 'UNISEX SHOES', 4500.00, 5, 'unnamed.jpg', 'unnamed1.jpg', '2014-05-27 05:30:53', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(35, 19, 'MEXICO 66 SLIP-ON', 'UNISEX SHOES', 3500.00, 5, '314e0148a6a84dd880561df6240376b7.jpg', '314e0148a6a84dd880561df6240376b71.jpg', '2014-05-27 05:33:27', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(36, 19, 'ULTIMATE 81 NM', 'UNISEX SHOES', 8900.00, 8, 'onitsuka-tiger-ultimate-81-fashion-sneaker-negro-negro-blanco-14-d-m-us-negro-blanco-9391-main.jpg', 'onitsuka-tiger-ultimate-81-fashion-sneaker-negro-negro-blanco-14-d-m-us-negro-blanco-9391-main1.jpg', '2014-05-27 05:34:33', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(37, 19, 'REBILAC RUNNER', 'UNISEX SHOES', 3900.00, 3, 'onitsuka-tiger-rebilac-runner-mako-blue-white-1183b417-400.jpg', 'onitsuka-tiger-rebilac-runner-mako-blue-white-1183b417-4001.jpg', '2014-05-27 05:35:28', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(38, 20, 'Nike Air Max 2090', 'นำอดีตมาสู่อนาคตด้วย Nike Air Max 2090 ซึ่งมาในลุคโดดเด่นที่ได้แรงบันดาลใจจาก DNA ของ Air Max 90 เจ้าเอกลักษณ์', 5200.00, 0, 'รองเท้าผู้-air-max-2090-kvnJ2W.jpg', 'รองเท้าผู้-air-max-2090-kvnJ2W1.jpg', '2014-05-27 05:38:28', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(40, 11, 'Nike Air Force 1 ''07 SE', 'คู่ตำนานนี้ตกแต่งมาเพื่ออนาคต โดยเป็นการออกแบบที่คำนึงถึงความยั่งยืนส่วนหุ้มชั้นนอกแบบเย็บติดที่ส่วนบนเพิ่มสไตล์ระดับตำนาน ความทนทาน และการรองรับ', 3800.00, 32, 'รองเท้าผู้-air-force-1-07-se-Zvf6pd.jpg', 'รองเท้าผู้-air-force-1-07-se-Zvf6pd1.jpg', '2014-05-27 19:32:22', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(41, 11, 'Nike AF1 Pixel SE', 'เป๊ะปังด้วย Nike Air Force 1 Pixel SE ซึ่งเป็นรองเท้าสไตล์นอกคอร์ทปรับโฉมใหม่ที่ดีไซน์โดยผู้หญิงและเพื่อผู้หญิง', 4200.00, 2, '', '', '2014-05-27 19:32:45', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(42, 11, 'Nike Air Force 1 Shadow', 'Nike Air Force 1 Shadow ใส่ลูกเล่นสนุกสนานให้กับรองเท้าบาสดีไซน์คลาสสิก', 4200.00, 2, '', '', '2014-05-27 19:33:05', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(43, 11, 'Nike Air Force 1 Crater', 'สนีกเกอร์ที่ช่วยนิยามสไตล์สตรีทปรับโฉมมาใหม่ด้วยโฟม Crater เพื่อใช้ส่วนประกอบที่เป็นวัสดุรีไซเคิลอย่างน้อย 20%', 4200.00, 0, '', '', '2014-05-27 19:33:37', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(44, 20, 'Nike Air Max 2090 EOI', 'นำอดีตไปสู่อนาคตด้วย Nike Air Max 2090 EOI ซึ่งมาในลุคโดดเด่นที่ได้แรงบันดาลใจจาก DNA ของ Air Max 90 สุดเลื่องชื่อ', 5800.00, 10, 'รองเท้าผู้-air-max-2090-eoi-MG95bX.jpg', 'รองเท้าผู้-air-max-2090-eoi-MG95bX1.jpg', '2014-05-02 18:37:56', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(45, 24, 'KEDS Kickstart Scribble สี LAVENDER รองเท้าผ้าใบผู้หญิง', 'รองเท้าผ้าใบผู้หญิง KEDS รุ่น Kickstart Scribble สี LAVENDER', 1125.00, 9, '9dc283aacefcfadd65550607042e70d2.jpg', '9dc283aacefcfadd65550607042e70d21.jpg', '2014-05-02 18:39:19', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(46, 25, 'REEBOK Energylux Driftium รองเท้าวิ่งผู้ชาย', 'พื้นรองเท้าด้านในมอบความนุ่มและรองรับแรงกระแทกในจจังหวะการลงน้ำหนัก', 999.00, 17, '5ddc9c89Nc74b0ffbjpg!q70.jpg', '5ddc9c89Nc74b0ffbjpg!q701.jpg', '2014-05-02 18:40:51', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(47, 18, 'NEW BALANCE M490CM5 V5 2E FIT รองเท้าวิ่งผู้ชาย', 'NEW BALANCE M490CM5 V5 2E FIT รองเท้าวิ่งผู้ชาย', 2550.00, 64, 'newbalance-thailand-3367-27652-1.jpg', 'newbalance-thailand-3367-27652-11.jpg', '2014-05-02 18:42:15', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(48, 26, 'Vans Old Skool Core', 'Vans รองเท้าผ้าใบผู้ชายรุ่น Old Skool Core', 2400.00, 5, 'jd_VN000D3HY28_a.jpg', 'jd_VN000D3HY28_a1.jpg', '2014-05-02 18:50:29', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(49, 26, 'Vans UA CLassic Slip-On Bandana', 'Vans รองเท้าผู้ชาย UA CLassic Slip-On Bandana', 2300.00, 42, 'jd_VN0A33TBD9S_e.jpg', 'jd_VN0A33TBD9S_e1.jpg', '2014-05-02 18:51:17', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(50, 26, 'Vans Bandana Style 36', 'Vans รองเท้าผู้ชาย Bandana Style 36', 2800.00, 43, 'jd_VN0A54F6D9S_b.jpg', 'jd_VN0A54F6D9S_b1.jpg', '2014-05-02 18:52:14', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(51, 26, 'Vans Old Skool Mule', 'Vans รองเท้าผู้ชาย Old Skool Mule', 2800.00, 33, 'jd_VN0A4P3Y5GU_b.jpg', 'jd_VN0A4P3Y5GU_b1.jpg', '2014-05-02 18:53:15', '0000-00-00 00:00:00');
INSERT INTO `tbl_product` VALUES(52, 26, 'Vans SK8 Hi Core', 'Vans รองเท้าผ้าใบผู้ชายรุ่น SK8 Hi Core', 2600.00, 37, 'jd_VN000D5IB8C_b.jpg', 'jd_VN000D5IB8C_b1.jpg', '2014-05-02 18:54:10', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_shop_config`
--

DROP TABLE IF EXISTS `tbl_shop_config`;
CREATE TABLE IF NOT EXISTS `tbl_shop_config` (
  `sc_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sc_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sc_phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sc_email` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `sc_shipping_cost` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sc_currency` int(10) unsigned NOT NULL DEFAULT '1',
  `sc_order_email` enum('y','n') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'n'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- dump ตาราง `tbl_shop_config`
--

INSERT INTO `tbl_shop_config` VALUES('Edit by zoneteen', '999 Bangkok Thailand', '099-999-9999', 'pongpaldee@gmail.com', 100.00, 5, 'y');

-- --------------------------------------------------------

--
-- โครงสร้างตาราง `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_password` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_regdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_last_login` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_role` enum('customer','guest','admin') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'guest',
  `user_first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_address` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_phone` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_city` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_state` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_postal_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

--
-- dump ตาราง `tbl_user`
--

INSERT INTO `tbl_user` VALUES(1, 'admin', '3db642be86807e195c422694d9f9094b', '2021-02-20 17:35:44', '2021-05-05 08:53:17', 'admin', 'ผู้ดูแลระบบ', 'เว็บมาสเตอร์', 'admin@zoneteen.com', '9 หมู่ 9', '099-999-999', 'เมือง', 'นนทบุรี', '11120');
INSERT INTO `tbl_user` VALUES(2, 'zoneteen', '05e0e1e2ca4d93be2d59071e2c82cfed', '2021-03-02 17:52:51', '2021-05-03 15:54:46', 'customer', 'ชื่อครับ', 'นามสกุลค่ะ', 'zoneteen@hotmail.com', '123/321 หมู่บ้าน ประดับดาว', '089-888-9999', 'เมือง', 'นนทบุรี', '10110');
