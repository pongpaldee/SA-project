<?php
ini_set('display_errors', 'On');

error_reporting(E_ALL ^ E_DEPRECATED);


session_start();

$dbHost = 'localhost';
$dbUser = 'webmaster';
$dbPass = 'pass';
$dbName = 'zoneteen';

$thisFile = str_replace('\\', '/', __FILE__);
$docRoot = $_SERVER['DOCUMENT_ROOT'];

$webRoot  = str_replace(array($docRoot, 'library/config.php'), '', $thisFile);
$srvRoot  = str_replace('library/config.php', '', $thisFile);

define('WEB_ROOT', $webRoot);
define('SRV_ROOT', $srvRoot);
define('SECRET_KEY', 'zoneteen');
define('CATEGORY_IMAGE_DIR', 'images/category/');
define('PRODUCT_IMAGE_DIR',  'images/product/');
define('POWER_BY','<p>Thank you for visited</p>');
define('MAX_CATEGORY_IMAGE_WIDTH', 125);
define('LIMIT_PRODUCT_WIDTH',     true);
define('MAX_PRODUCT_IMAGE_WIDTH', 300);
define('THUMBNAIL_WIDTH',         125);
require_once 'database.php';
require_once 'common.php';

$shopConfig = getShopConfig();
?>