<p>&nbsp;</p>
<p><small>&copy; 2021 MyOnlineShop&nbsp;</small></p>
</body>
</html>